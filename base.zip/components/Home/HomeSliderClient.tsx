"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";

const AUTOPLAY_MS = 6000;
const SWIPE_FRACTION = 0.15;
const SETTLE_MS = 480;

type Slide = { image: string; alt: string };

export default function HomeSliderClient({
  slides,
  labels,
}: {
  slides: Slide[];
  labels: string[];
}) {
  const count = slides.length;
  const hasLoop = count > 1;

  // trackPos: 0 = cloneLast, 1..count = real slides, count+1 = cloneFirst
  const [trackPos, setTrackPos] = useState(1);
  const trackPosRef = useRef(1);
  const [mounted, setMounted] = useState(false);
  const [paused, setPaused] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [settling, setSettling] = useState(false);

  const rootRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const widthRef = useRef(1);
  const startXRef = useRef(0);
  const pointerIdRef = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);
  const dragOffsetRef = useRef(0);
  const settlingRef = useRef(false);

  // real index for dots (0..count-1)
  const realIndex = ((trackPos - 1) % count + count) % count;

  useEffect(() => { trackPosRef.current = trackPos; }, [trackPos]);
  useEffect(() => { const id = requestAnimationFrame(() => setMounted(true)); return () => cancelAnimationFrame(id); }, []);

  // measure width
  useEffect(() => {
    const measure = () => { widthRef.current = rootRef.current?.clientWidth || 1; };
    measure();
    const ro = new ResizeObserver(measure);
    if (rootRef.current) ro.observe(rootRef.current);
    window.addEventListener("orientationchange", measure);
    return () => { ro.disconnect(); window.removeEventListener("orientationchange", measure); };
  }, []);

  const setTrackTransition = useCallback((enabled: boolean) => {
    if (!trackRef.current) return;
    trackRef.current.style.transition = enabled
      ? `transform ${SETTLE_MS}ms cubic-bezier(0.22,1,0.36,1)`
      : "none";
  }, []);

  const setTrackTransform = useCallback((pos: number, dragX: number) => {
    if (!trackRef.current) return;
    const w = widthRef.current || 1;
    const dragPct = (dragX / w) * 100;
    const x = -pos * 100 + dragPct;
    trackRef.current.style.transform = `translate3d(${x}%,0,0)`;
  }, []);

  // keep transform in sync when pos changes (without drag)
  useEffect(() => {
    if (!dragging && !settlingRef.current) {
      // ensure no transition flash when we snap clone -> real
      setTrackTransform(trackPos, 0);
    }
  }, [trackPos, dragging, setTrackTransform]);

  // init transform
  useEffect(() => {
    setTrackTransition(false);
    setTrackTransform(1, 0);
    requestAnimationFrame(() => requestAnimationFrame(() => setTrackTransition(true)));
  }, [setTrackTransform, setTrackTransition]);

  const handleSnapIfNeeded = useCallback((pos: number) => {
    // if we landed on clone, snap to real counterpart without animation
    if (pos === 0) {
      // cloneLast -> real last (count)
      setTrackTransition(false);
      setTrackPos(count);
      setTrackTransform(count, 0);
      requestAnimationFrame(() => requestAnimationFrame(() => {
        setTrackTransition(true);
        settlingRef.current = false;
        setSettling(false);
      }));
      return true;
    }
    if (pos === count + 1) {
      // cloneFirst -> real first (1)
      setTrackTransition(false);
      setTrackPos(1);
      setTrackTransform(1, 0);
      requestAnimationFrame(() => requestAnimationFrame(() => {
        setTrackTransition(true);
        settlingRef.current = false;
        setSettling(false);
      }));
      return true;
    }
    settlingRef.current = false;
    setSettling(false);
    return false;
  }, [count, setTrackTransform, setTrackTransition]);

  const animateToPos = useCallback((nextPos: number) => {
    if (settlingRef.current || dragging) return;
    settlingRef.current = true;
    setSettling(true);
    setTrackTransition(true);
    dragOffsetRef.current = 0;
    setTrackTransform(nextPos, 0);
    setTrackPos(nextPos);
  }, [dragging, setTrackTransform, setTrackTransition]);

  const animateTo = useCallback((dir: "next" | "prev" | number) => {
    if (settlingRef.current || dragging || !hasLoop) return;
    if (typeof dir === "number") {
      const targetReal = ((dir % count) + count) % count;
      if (targetReal === realIndex) return;
      // jump directly if not adjacent - snap without direction confusion
      // For dots we allow direct jump with correct direction visual
      // Compute shortest forward distance, but animate one step in preferred direction only if adjacent
      // If distance >1, do instant jump (no flash, no long travel)
      const curPos = trackPosRef.current;
      const curReal = realIndex;
      const diff = (targetReal - curReal + count) % count;
      if (diff !== 1 && diff !== count - 1) {
        // far jump: snap instantly
        const newPos = targetReal + 1;
        setTrackTransition(false);
        setTrackPos(newPos);
        setTrackTransform(newPos, 0);
        requestAnimationFrame(() => requestAnimationFrame(() => setTrackTransition(true)));
        return;
      }
      // adjacent: go to neighbor pos
      const nextPos = diff === 1 ? curPos + 1 : curPos - 1;
      animateToPos(nextPos);
      return;
    }
    const cur = trackPosRef.current;
    animateToPos(dir === "next" ? cur + 1 : cur - 1);
  }, [dragging, hasLoop, count, realIndex, animateToPos, setTrackTransform, setTrackTransition]);

  // transition end handler for track
  const handleTransitionEnd = useCallback((e: React.TransitionEvent<HTMLDivElement>) => {
    if (e.propertyName !== "transform") return;
    if (!settlingRef.current) return;
    const pos = trackPosRef.current;
    // check clone snap
    if (pos === 0 || pos === count + 1) {
      handleSnapIfNeeded(pos);
    } else {
      settlingRef.current = false;
      setSettling(false);
    }
  }, [count, handleSnapIfNeeded]);

  // autoplay
  useEffect(() => {
    if (paused || dragging || settling || !hasLoop) return;
    const t = window.setInterval(() => animateTo("next"), AUTOPLAY_MS);
    return () => window.clearInterval(t);
  }, [paused, dragging, settling, hasLoop, animateTo]);

  // fallback for snap if transitionend not fired
  useEffect(() => {
    if (!settling) return;
    const id = window.setTimeout(() => {
      if (settlingRef.current) {
        const pos = trackPosRef.current;
        if (pos === 0 || pos === count + 1) handleSnapIfNeeded(pos);
        else { settlingRef.current = false; setSettling(false); }
      }
    }, SETTLE_MS + 80);
    return () => window.clearTimeout(id);
  }, [settling, count, handleSnapIfNeeded]);

  // pointer handlers
  function handlePointerDown(e: React.PointerEvent<HTMLDivElement>) {
    if (!hasLoop || settlingRef.current) return;
    const t = e.target as HTMLElement;
    if (t.closest("button")) return;
    widthRef.current = rootRef.current?.clientWidth || 1;
    pointerIdRef.current = e.pointerId;
    startXRef.current = e.clientX;
    dragOffsetRef.current = 0;
    setDragging(true);
    setPaused(true);
    setTrackTransition(false);
    try { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); } catch {}
  }
  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    if (!dragging || pointerIdRef.current !== e.pointerId) return;
    const delta = e.clientX - startXRef.current;
    const w = widthRef.current || 1;
    const clamped = Math.max(Math.min(delta, w), -w);
    dragOffsetRef.current = clamped;
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => setTrackTransform(trackPosRef.current, clamped));
  }
  function handlePointerUp(e: React.PointerEvent<HTMLDivElement>) {
    if (!dragging || pointerIdRef.current !== e.pointerId) return;
    pointerIdRef.current = null;
    setDragging(false);
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    const delta = e.clientX - startXRef.current;
    const w = widthRef.current || 1;
    if (Math.abs(delta) < w * SWIPE_FRACTION) {
      setTrackTransition(true);
      setTrackTransform(trackPosRef.current, 0);
      window.setTimeout(() => setPaused(false), SETTLE_MS);
      return;
    }
    const dir = delta < 0 ? 1 : -1; // next = +1 pos, prev = -1
    const nextPos = trackPosRef.current + dir;
    // start settling animation to nextPos
    settlingRef.current = true;
    setSettling(true);
    setTrackTransition(true);
    setTrackTransform(nextPos, 0);
    setTrackPos(nextPos);
  }
  function handlePointerCancel(e: React.PointerEvent<HTMLDivElement>) {
    if (pointerIdRef.current !== e.pointerId) return;
    pointerIdRef.current = null;
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    setDragging(false);
    settlingRef.current = false;
    setSettling(false);
    setTrackTransition(true);
    setTrackTransform(trackPosRef.current, 0);
    setPaused(false);
  }

  // build track items: [lastClone, ...slides, firstClone]
  const trackItems = hasLoop
    ? [slides[count - 1], ...slides, slides[0]]
    : slides;

  return (
    <div
      ref={rootRef}
      className={`relative h-[70svh] min-h-[440px] w-full select-none overflow-hidden bg-[#0F1B22] lg:h-[78svh] ${mounted ? "opacity-100" : "opacity-0"}`}
      style={{ transition: "opacity 700ms cubic-bezier(0.22,1,0.36,1)", touchAction: "pan-y", cursor: hasLoop ? (dragging ? "grabbing" : "grab") : undefined }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => { if (!dragging && !settling) setPaused(false); }}
    >
      <div
        ref={trackRef}
        className="flex h-full w-full"
        style={{ transform: "translate3d(-100%,0,0)", willChange: dragging || settling ? "transform" : "auto" }}
        onTransitionEnd={handleTransitionEnd}
      >
        {trackItems.map((slide, i) => {
          const isClone = hasLoop && (i === 0 || i === trackItems.length - 1);
          return (
            <div key={`${slide.image}-${i}`} className="relative h-full w-full shrink-0 basis-full overflow-hidden">
              <Image
                src={slide.image}
                alt={isClone ? "" : slide.alt}
                aria-hidden={isClone}
                fill
                priority={i === 1}
                sizes="100vw"
                draggable={false}
                className="pointer-events-none object-cover"
              />
            </div>
          );
        })}
      </div>

      {hasLoop && (
        <>
          <button type="button" onClick={() => animateTo("next")} aria-label="اسلاید بعدی" className="absolute left-4 top-1/2 z-20 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/25 bg-black/20 text-white backdrop-blur-sm transition hover:bg-white/15 sm:flex">←</button>
          <button type="button" onClick={() => animateTo("prev")} aria-label="اسلاید قبلی" className="absolute right-4 top-1/2 z-20 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/25 bg-black/20 text-white backdrop-blur-sm transition hover:bg-white/15 sm:flex">→</button>
          <div className="pointer-events-none absolute inset-x-0 bottom-5 z-20 flex justify-center gap-2">
            {labels.map((label, i) => (
              <button key={`${label}-${i}`} type="button" onClick={() => animateTo(i)} aria-label={`نمایش اسلاید ${i + 1}`} aria-current={i === realIndex} className={`pointer-events-auto h-1.5 rounded-full transition-all duration-300 ${i === realIndex ? "w-6 bg-white" : "w-1.5 bg-white/40 hover:bg-white/70"}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
